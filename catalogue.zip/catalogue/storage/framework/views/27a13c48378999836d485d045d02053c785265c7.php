<?php $__env->startSection('pageTitle','Profile :: Change Password'); ?>
<?php $__env->startSection('content'); ?>
<div class="col-xl-12">
<?php echo $__env->make('admin.partials.messages', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo $__env->make('admin.partials.form-error-messages', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	<div class="card">
		<form class="form-horizontal" action="<?php echo e(route('admin.profile.update')); ?>" method="post" enctype= "multipart/form-data">
			<?php echo csrf_field(); ?>


			<table class="table table-bordered" style="width: 100%;">
				<tr>
					<th width="20%">Profile Image:</th>
					<td>
						<img src="<?php echo e(my_asset('storage/uploads/user_images')); ?>/<?php echo e(($userInfo->profile_image)); ?>" width="100px" height="100px"/>
						<input type="file" class="form-control" id="profile_image" name="profile_image" placeholder="Select profile image file">
					</td>
				</tr>
				<tr>
					<th>First Name:</th>
					<td>
						<input type="text" class="form-control" id="first_name" name="first_name" placeholder="Enter first name" value="<?php echo e(old('first_name',$userInfo->first_name)); ?>">
					</td>
				</tr>
				<tr>
					<th>Last Name:</th>
					<td>
						<input type="text" class="form-control" id="last_name" name="last_name" placeholder="Enter last name" value="<?php echo e(old('last_name',$userInfo->last_name)); ?>">
					</td>
				</tr>
				<tr>
					<th>Email:</th>
					<td>
						<input type="text" class="form-control" id="email" name="email" placeholder="Enter email" value="<?php echo e(old('mobile',$userInfo->email)); ?>">
					</td>
				</tr>
				<tr>
					<th></th>
					<td>
						<button type="submit" class="btn btn-primary">Save</button>
					</td>
				</tr>
			</table>
		</form>
  	</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.adminApp', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>