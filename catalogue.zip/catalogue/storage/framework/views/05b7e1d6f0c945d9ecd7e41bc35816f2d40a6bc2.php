<?php $__env->startSection('pageTitle','Profile :: Show'); ?>
<?php $__env->startSection('content'); ?>
<div class="col-xl-12">
<?php echo $__env->make('admin.partials.messages', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo $__env->make('admin.partials.form-error-messages', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	<div class="card">	
		<table class="table table-bordered" style="width: 100%;">
			<tr>
				<th width="20%">Profile Image:</th>
				<td>
					<img src="<?php echo e(my_asset('storage/uploads/user_images')); ?>/<?php echo e(($userInfo->profile_image)); ?>" width="100px" height="100px"/>
				</td>
			</tr>
			<tr>
				<th>First Name:</th>
				<td>
					<?php echo e($userInfo->first_name); ?>

				</td>
			</tr>
			<tr>
				<th>Last Name:</th>
				<td>
					<?php echo e($userInfo->last_name); ?>

				</td>
			</tr>
			<tr>
				<th>Email:</th>
				<td>
					<?php echo e($userInfo->email); ?>

				</td>
			</tr>
			
			<tr>
				<th>Created At:</th>
				<td>
					<?php echo e($userInfo->created_at); ?>

				</td>
			</tr>
			<tr>
				<th>Updated At:</th>
				<td>
					<?php echo e($userInfo->updated_at); ?>

				</td>
			</tr>
			<tr>
				<th>Status:</th>
				<td>
					<?php echo e($userInfo->getStatus->name); ?>

				</td>
			</tr>
			<tr>
				<th></th>
				<td>
					<a class="btn btn-primary" href="<?php echo e(route('admin.profile.edit')); ?>">Edit</a>
				</td>
			</tr>
		</table>
	</div> 
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.adminApp', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>