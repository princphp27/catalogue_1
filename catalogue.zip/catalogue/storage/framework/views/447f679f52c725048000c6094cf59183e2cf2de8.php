<?php $__env->startSection('pageTitle','Categories'); ?>
<?php $__env->startSection('content'); ?>
<div class="col-xl-12">
<?php echo $__env->make('admin.partials.messages', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo $__env->make('admin.partials.form-error-messages', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	<div class="card">
		<div class="card-header">Create</div>
			<div class="card-body">
				<div class="table-responsive">
				<form class="form-horizontal" action="<?php echo e(route('admin.categories.store')); ?>" method="post" enctype= "multipart/form-data">
					<?php echo csrf_field(); ?>

					
					<table class="table table-bordered" style="width: 100%;">
						<tr>
                             
							<th width="20%">Client List:</th>
							<td>
								<select class="form-control" name="client_id" placeholder="Select Client List">
									<option value="">---Select---</option>

									
									<?php $__currentLoopData = $Clients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $client): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
											
										<option value="<?php echo e($client->id); ?>" <?php echo e((old('client_id') == $client->id)?" SELECTED":""); ?>><?php echo e($client->name); ?></option>
									}
									}
									<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

								</select>
								
							</td>
						</tr>
				
						<tr>
							<th>Name:</th>
							<td>
								<input type="text" class="form-control" id="name" name="name" placeholder="Enter category name" value="<?php echo e(old('name')); ?>">
							</td>
						</tr>
						<tr>
							<th>Image:</th>
							<td>
								<input type="file" class="form-control" id="image" name="image" placeholder="Select image file">
							</td>
						</tr>
						<tr>
							<th>Status:</th>
							<td>
								<label class="radio-inline"><input type="radio" name="status" value="1" checked="checked"> Active</label>
								<label class="radio-inline"><input type="radio" name="status" value="0"> Inactive</label>
							</td>
						</tr>
						<tr>
							<th></th>
							<td>
								<button type="submit" class="btn btn-primary">Create</button>
							</td>
						</tr>	
					</table>
				</form>
			</div>	
		</div>	
	</div>
</div>	
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.adminApp', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>