<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<!-- CSRF Token -->
<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
<title><?php echo e(config('app.name', 'The Nearest::Admin')); ?></title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="<?php echo e(my_asset('fonts/font-awesome.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(my_asset('lib/bootstrap/bootstrap.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(my_asset('lib/dataTables.bootstrap4.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(my_asset('css/admin/style.css')); ?>">
    