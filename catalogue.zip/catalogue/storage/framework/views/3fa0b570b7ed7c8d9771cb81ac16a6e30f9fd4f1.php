<?php if(Session::has('error_message')): ?>
<p class="alert alert-danger"><?php echo e(Session::get('error_message')); ?></p>
<?php endif; ?>
<?php if(Session::has('success_message')): ?>
<p class="alert alert-success"><?php echo e(Session::get('success_message')); ?></p>
<?php endif; ?>
<?php if(Session::has('message')): ?>
<p class="alert alert-info"><?php echo e(Session::get('message')); ?></p>
<?php endif; ?>