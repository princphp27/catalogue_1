<?php $__env->startSection('pageTitle','Sub Categories'); ?>
<?php $__env->startSection('content'); ?>
<div class="col-xl-12">
<?php echo $__env->make('client.partials.messages', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo $__env->make('client.partials.form-error-messages', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	<div class="card">
		<div class="card-header">Detail</div>
		<div class="card-body">
			<div class="table-responsive">
				<table class="table table-bordered" style="width: 100%;">
					<tr>
						<th width="20%">Category:</th>
						<td><?php echo e(($categoryInfo->getParentCategory) ? $categoryInfo->getParentCategory->name :"N/A"); ?></td>
					</tr>
					<tr>

						<th>Sub Category Name:</th>

						<td><?php echo e($categoryInfo->name); ?></td>
					</tr>
					
					<tr>

							<th>Description:</th>

							<td><?php echo e($categoryInfo->description); ?></td>
						</tr>
					<tr>
						<th>Created At:</th>
						<td><?php echo e($categoryInfo->created_at); ?></td>
					</tr>
					<tr>
						<th>Updated At:</th>
						<td><?php echo e($categoryInfo->updated_at); ?></td>
					</tr>
					<tr>
						<th>Status:</th>
						<td><?php echo e($categoryInfo->getStatus->name); ?></td>
					</tr>
					<tr>
						<th>Image:</th>
						<td>
							<img src="<?php echo e(getCategoryImageUrl($categoryInfo->image)); ?>" width="150px" height="100px"/>
						</td>
					</tr>
					<tr>
						<th>Banners:</th>
						<td>

							<?php
							$banners = $categoryInfo->getBanners;
							?>
							<?php if($banners): ?>
								<?php $__currentLoopData = $banners; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $banner): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									<div class="category-banner-container"><img src="<?php echo e(getCategoryBannerImageUrl($banner->image)); ?>"/></div>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							<?php endif; ?>
						</td>
					</tr>
					<tr>
							<th></th>
							<td>
								<a href="<?php echo e(route('client.sub-categories.edit',['id'=>$categoryInfo->id])); ?>" class="btn btn-primary">Edit</a>
							</td>
						</tr>	
				</table>
			</div>
		</div>	
	</div> 
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('client.layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>