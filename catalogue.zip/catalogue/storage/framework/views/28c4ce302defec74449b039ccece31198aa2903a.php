<script src="<?php echo e(my_asset('lib/jquery-2.1.4.min.js')); ?>"></script>
<script src="<?php echo e(my_asset('lib/jquery-3.2.1.slim.min.js')); ?>"></script>
<script src="<?php echo e(my_asset('lib/popper.min.js')); ?>"></script>
<script src="<?php echo e(my_asset('lib/bootstrap.min.js')); ?>"></script>
<script src="<?php echo e(my_asset('lib/jquery.dataTables.min.js')); ?>"></script>
<script src="<?php echo e(my_asset('lib/dataTables.bootstrap4.min.js')); ?>"></script>
<script src="<?php echo e(my_asset('js/admin/common.js')); ?>"></script>