<?php $__env->startSection('pageTitle','Products'); ?>
<?php $__env->startSection('content'); ?>
<div class="btn-group pull-right">
		<a href="<?php echo e(route('client.products.create')); ?>" class="btn btn-primary" style="margin-right:20px;"><i class="fa fa-plus">     Add New Product</i></a>
	</div>
<div class="col-xl-12">
<?php echo $__env->make('client.partials.messages', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo $__env->make('client.partials.form-error-messages', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<!-- <div class="btn-group pull-right">
		<a href="<?php echo e(route('client.products.create')); ?>" class="btn btn-primary">Add New Product</a>
	</div> -->
	<div class="card">
		<div class="card-header">Detail</div>
		
		<div class="card-body">
			<div class="table-responsive">
				<table class="table table-bordered" style="width: 100%;">

					<tr>
						<th width="20%">Product Name:</th>
						<td><?php echo e($dataInfo->name); ?></td>
					</tr>
					<tr>

							<th>Product Price :</th>

							<td>
								<?php
								$price = $dataInfo->getPrices()->where('status',1)->get()->first();
								$price = ($price) ? $price->product_price :"";
								?>
								<?php echo e($price); ?>

							</td>
						</tr>
					<tr>
						<th>Category:</th>
						<td><?php echo e($dataInfo->getCategory->name); ?> <i class="fa fa-arrow-right"></i> <?php echo e($dataInfo->name); ?></td>
					</tr>
					<tr>
						<th>Description:</th>
						<td><?php echo e($dataInfo->description); ?></td>
					</tr>
					
					<tr>
						<th>Specifications:</th>
						<td>
							<?php
							$specifications = $dataInfo->getSpecifications;
							?>
							<?php if($specifications): ?>
								<?php $__currentLoopData = $specifications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $spec): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	
									<div class="row" style="margin-top:5px;">
									<div class="col-md-1">
										<label>Key:</label>
									</div>
									<div class="col-md-4">
										<?php echo e($spec->product_key); ?>

									</div>
									<div class="col-md-1">
										<label>Value:</label>
									</div>
									<div class="col-md-4">
										<?php echo e($spec->product_value); ?>

									</div>
									<div class="col-md-1">
										
									</div>
								</div>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							<?php endif; ?>
							
						</td>
					</tr>
					<tr>
						<th>Created At:</th>
						<td><?php echo e($dataInfo->created_at); ?></td>
					</tr>
					<tr>
						<th>Updated At:</th>
						<td><?php echo e($dataInfo->updated_at); ?></td>
					</tr>
					<tr>
						<th>Status:</th>
						<td><?php echo e($dataInfo->getStatus->name); ?></td>
					</tr>
					<tr>
						<th>Images:</th>
						<td>
							<?php
								$images = $dataInfo->getImages;
							?>
							<?php if($images): ?>
								<?php $__currentLoopData = $images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $img): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									<div class="product-image-container"><img src="<?php echo e(getProductImageUrl($img->image)); ?>"/></div>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							<?php endif; ?>
						</td>
					</tr>
					<tr>
						<th>Banners:</th>
						<td>
							<?php
								$banners = $dataInfo->getBanners;
							?>
							<?php if($images): ?>
								<?php $__currentLoopData = $banners; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $banner): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									<div class="product-banner-container"><img src="<?php echo e(getProductBannerImageUrl($banner->image)); ?>"/></div>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							<?php endif; ?>
						</td>
					</tr>
					<tr>
						<th>&nbsp;</th>
						<td><a href="<?php echo e(route('client.products.edit',['id'=>$dataInfo->id])); ?>" class="btn btn-primary">Edit</a></td>
					</tr>
				</table>
			</div>
		</div>	
	</div> 
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('client.layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>