<?php $__env->startSection('content'); ?>
<div class="container">
	<div class="row">
		<div class="col-md-6 mx-auto">
			<img src="<?php echo e(my_asset('images/logo.png')); ?>" height="150px"/>
			<div class="card">
				<div class="card-header">Admin Login</div>
				<div class="card-body">
					<?php echo $__env->make('admin.partials.messages', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
					<?php echo $__env->make('admin.partials.form-error-messages', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
						
					<form id="form_login" action="<?php echo e(route('admin.login')); ?>" method="post">
						<?php echo e(csrf_field()); ?>

					  <div class="form-group">
							<input type="text" name="email" class="form-control" placeholder="Email" value="<?php echo e(old('email')); ?>" required autofocus>
					  </div>
					  
					  <div class="form-group">
							<input type="password" class="form-control" placeholder="Password" name="password" required>
					  </div>
					  <div class="button-holder text-right">
						<button type="submit" class="btn btn-primary">Login</button>
					  </div>
					</form>
				</div>
			</div>
		</div>
	</div>
</div>	
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.default', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>