<?php $__env->startSection('pageTitle','Clients'); ?>

<?php $__env->startSection('content'); ?>
<div class="col-xl-12">
	<?php echo $__env->make('admin.partials.messages', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	<?php echo $__env->make('admin.partials.form-error-messages', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	
	<div class="btn-group pull-right">
		<a href="<?php echo e(route('admin.clients.create')); ?>" class="btn btn-primary">New Client</a>

	</div>
	<div class="clearfix"></div>
	<div class="card">
		<div class="card-header">List</div>
		<div class="card-body">
			<div class="table-responsive">
				<table id="table-list" class="table table-bordered" style="width:100%;cellpadding:0; cellspacing:0;">
				  <thead>
					<tr>
					  <th>#ID</th>

					  <th>Name</th>
					  <th>Phone</th>
					  <th>Email</th>
					  <th>Contact</th>
					  <th>Contact mobile</th>
					  <th>Contact Email</th>
					  <!-- <th>Client Key</th> -->
					  <th>Status</th>
					  <th>Action</th>
					</tr>
				  </thead>
				  <tbody>
					<?php if($dataList && count($dataList)>0): ?>
						<?php $__currentLoopData = $dataList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<tr>
							  <th scope="row"><?php echo e($row->id); ?></th>


							  <td><?php echo e($row->name); ?></td>
							  <td><?php echo e($row->phone); ?></td>
							  <td><?php echo e($row->email); ?></td>
							  <td><?php echo e($row->contact_name); ?></td>
							  <td><?php echo e($row->contact_mobile); ?></td>
							  <td><?php echo e($row->contact_email); ?></td>
							   <!-- <td><?php echo e($row->client_key); ?></td> -->
							  <td><?php echo e($row->getStatus->name); ?></td>
							  <td width="80px">

								<a href="<?php echo e(route('admin.clients.show',['id'=>$row->id])); ?>"><i class="fa fa-info-circle" title="View"></i></a>
								<a href="<?php echo e(route('admin.clients.edit',['id'=>$row->id])); ?>"><i class="fa fa-edit" title="Edit"></i></a>
								<a href="<?php echo e(route('admin.clients.delete',['id'=>$row->id])); ?>"><i class="fa fa-trash-o btn-delete" title="Remove" data-id="<?php echo e($row->id); ?>"></i></a>

							</td>
							</tr>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					<?php endif; ?>	
				  </tbody>
				</table>
				
			</div>
		</div>	
	</div>	
</div>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
<script type="text/javascript">
	jQuery(document).ready(function() {

		jQuery('#table-list').DataTable();

	} );
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.adminApp', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>