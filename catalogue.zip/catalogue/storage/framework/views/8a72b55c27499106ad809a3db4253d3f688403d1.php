<?php $__env->startSection('pageTitle','Products'); ?>
<?php $__env->startSection('content'); ?>
<div class="col-xl-12">
<?php echo $__env->make('admin.partials.messages', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo $__env->make('admin.partials.form-error-messages', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	<div class="btn-group pull-right">
		<a href="<?php echo e(route('admin.products.create')); ?>" class="btn btn-primary"><i class="fa fa-plus-circle" aria-hidden="true"></i>  New Product</a>
	</div>
	<div class="clearfix"></div>
	<div class="card">
		<div class="card-header">List</div>
			<div class="card-body">
				<div class="table-responsive">
					<table id="table-products" class="table table-bordered" style="width:100%;cellpadding:0; cellspacing:0;">
						<thead>
						<tr>
						  <th scope="col">#ID</th>
						  <th scope="col">Product Name</th>
						 <th scope="col">Category Name<i class="fa fa-arrow-right"></i> SubCategory Name</th>
						  <th scope="col">Status</th>
						  <th scope="col">Created At</th>
						  <th scope="col">Action</th>
						</tr>
					  </thead>
					  <tbody>
					  	
						<?php $__currentLoopData = $dataList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

							<tr>
							  <th scope="row"><?php echo e($row->id); ?></th>
							  <td><?php echo e($row->name); ?></td>
							  <td><?php echo e($row->getpCategory->name); ?> <i class="fa fa-arrow-right"></i> <?php echo e($row->name); ?></td>
							  <td><?php echo e($row->getStatus->name); ?></td>
							  <td><?php echo e($row->created_at); ?></td>
							  <td width="100px">
									<a href="<?php echo e(route('admin.products.show',['id'=>$row->id])); ?>"><i class="fa fa-info-circle" title="View"></i></a>
									<a href="<?php echo e(route('admin.products.edit',['id'=>$row->id])); ?>"><i class="fa fa-edit" title="Edit"></i></a>

									<i class="fa fa-trash-o btn-delete" title="Remove" data-id="<?php echo e($row->id); ?>"></i>

									<form id="delete-form-<?php echo e($row->id); ?>" action="<?php echo e(route('admin.products.delete' , ['id'=>$row->id] )); ?>" method="POST" style="display: none;">
										<?php echo e(csrf_field()); ?>

										<?php echo e(method_field('DELETE')); ?>

										<?php echo e(csrf_field()); ?>

									</form>
								</td>
								
							</tr>
						
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					  </tbody>
					</table>
					
				</div>
			</div>
		</div>	
	</div>	
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
<script type="text/javascript">
	jQuery(document).ready(function() {
		jQuery('#table-products').DataTable();

		
		jQuery(document).on("click",".btn-delete",function(event){
			var deletedId = jQuery(this).data("id");
			if(deletedId){
				if(confirm('Are you sure to delete?')){
					document.getElementById('delete-form-'+deletedId).submit();
				}
			}	
		});
	});

</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.adminApp', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>