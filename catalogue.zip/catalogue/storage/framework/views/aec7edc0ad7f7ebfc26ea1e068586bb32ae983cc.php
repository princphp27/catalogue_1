<!DOCTYPE html>
<html lang="<?php echo e(app()->getLocale()); ?>">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<!-- CSRF Token -->
<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
<title><?php echo e(config('app.name', 'Catalogue::Client')); ?></title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="<?php echo e(my_asset('fonts/font-awesome.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(my_asset('lib/bootstrap-4/css/bootstrap.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(my_asset('lib/dataTables/dataTables.bootstrap4.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(my_asset('css/style.css')); ?>">

<?php echo $__env->yieldContent('style'); ?>
</head>
<body>
<?php echo $__env->make('client.layouts.sidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<div id="right-panel" class="right-panel">
	<?php echo $__env->make('client.layouts.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	<div class="content mt-3">
		<?php echo $__env->make('client.layouts.breadcrumb', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
		<?php echo $__env->yieldContent('content'); ?>
	</div>
</div>
<?php echo $__env->make('client.layouts.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<script type="text/javascript">
var APP_URL = "<?php echo e(url('/')); ?>";
var APP_ASSETS_URL ="<?php echo e(my_asset('/')); ?>";
var IS_AUTHENTICATED = '<?php echo Auth::check();?>';
</script>
<script src="<?php echo e(my_asset('lib/jquery-2.1.4.min.js')); ?>"></script>
<script src="<?php echo e(my_asset('lib/popper.min.js')); ?>"></script>
<script src="<?php echo e(my_asset('lib/bootstrap-4/js/bootstrap.min.js')); ?>"></script>
<script src="<?php echo e(my_asset('lib/dataTables/jquery.dataTables.min.js')); ?>"></script>
<script src="<?php echo e(my_asset('lib/dataTables/dataTables.bootstrap4.min.js')); ?>"></script>
<script src="<?php echo e(my_asset('js/StorageHelpers.js')); ?>"></script>
<script src="<?php echo e(my_asset('js/Helpers.js')); ?>"></script>
<script src="<?php echo e(my_asset('js/ViewHelpers.js')); ?>"></script>
<script src="<?php echo e(my_asset('js/common.js')); ?>"></script>
<?php echo $__env->yieldContent('script'); ?>
</body>
</html>
