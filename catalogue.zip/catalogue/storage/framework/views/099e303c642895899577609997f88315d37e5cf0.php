<?php $__env->startSection('pageTitle','Settings'); ?>
<?php $__env->startSection('content'); ?>
<div class="col-xl-12">
<?php echo $__env->make('client.partials.messages', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo $__env->make('client.partials.form-error-messages', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	<div class="card">
		<div class="card-header">Theme :: Edit</div>
			<div class="card-body">
				<div class="table-responsive">
					<form class="form-horizontal" action="<?php echo e(route('client.theme.update')); ?>" method="post" enctype= "multipart/form-data">
						<?php echo csrf_field(); ?>

						<input name="_method" type="hidden" value="PUT">

						<table class="table table-bordered" style="width: 100%;">
							<tr>
								<th width="20%">Color Code:</th>
								<td>
									<input type="text" class="form-control" name="color_code" placeholder="" value="<?php echo e(old('color_code',($dataInfo) ? $dataInfo->color_code :'')); ?>">
								</td>
							</tr>
							<tr>
								<th></th>
								<td>
									<button type="submit" class="btn btn-primary">Save</button>
								</td>
							</tr>
						</table>
					</form>
				</div>
			</div>
		</div>	
	</div>
</div>	
<?php $__env->stopSection(); ?>
<?php echo $__env->make('client.layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>