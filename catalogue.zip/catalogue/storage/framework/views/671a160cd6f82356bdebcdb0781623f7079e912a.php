<?php $__env->startSection('pageTitle','Dashboard'); ?>

<?php $__env->startSection('content'); ?>
<div class="col-xl-12">
	<?php echo $__env->make('client.partials.messages', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	<?php echo $__env->make('client.partials.form-error-messages', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	<div class="card">
		<div class="card-body">
			<h2 class="text-center">Welcome to client dashboard</h2>
		</div>	
	</div> 
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('client.layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>