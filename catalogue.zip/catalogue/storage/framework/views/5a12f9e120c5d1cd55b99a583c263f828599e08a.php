<?php $__env->startSection('pageTitle','Categories'); ?>
<?php $__env->startSection('content'); ?>
<div class="col-xl-12">
<?php echo $__env->make('admin.partials.messages', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo $__env->make('admin.partials.form-error-messages', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	<div class="card">
		<div class="card-header">Detail</div>
			<div class="card-body">
				<div class="table-responsive">
					<table class="table table-bordered" style="width: 100%;">
						<tr>
							<th>Name:</th>
							<td><?php echo e($categoryInfo->name); ?></td>
						</tr>
						<tr>
							<th>Image:</th>
							<td>
								<img src="<?php echo e(my_asset('storage/uploads/category_images')); ?>/<?php echo e($categoryInfo->image); ?>" width="150px" height="100px"/>
							</td>
						</tr>
						<tr>
							<th>Created At:</th>
							<td><?php echo e($categoryInfo->created_at); ?></td>
						</tr>
						<tr>
							<th>Updated At:</th>
							<td><?php echo e($categoryInfo->updated_at); ?></td>
						</tr>
						<tr>
							<th>Status:</th>
							<td><?php echo e($categoryInfo->status); ?></td>
						</tr>
					</table>
				</div>
			</div>
		</div>	
	</div> 
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.adminApp', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>