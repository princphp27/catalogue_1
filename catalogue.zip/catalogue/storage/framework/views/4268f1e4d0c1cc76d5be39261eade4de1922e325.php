<!DOCTYPE html>
<html lang="<?php echo e(app()->getLocale()); ?>">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
<!-- CSRF Token -->
<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
<title><?php echo e(config('app.name', 'Catalogue')); ?></title>
<link href="<?php echo e(my_asset('fonts/font-awesome.min.css')); ?>" rel="stylesheet">
<link rel="stylesheet" href="<?php echo e(my_asset('lib/bootstrap-4/css/bootstrap.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(my_asset('css/admin/style.css')); ?>">
</head>
<body class="bg-white">
<div id="app">
	<?php echo $__env->yieldContent('content'); ?>
</div>
<script type="text/javascript">
	var APP_URL = "<?php echo e(url('/')); ?>";
	var APP_ASSETS_URL ="<?php echo e(my_asset('/')); ?>";
</script>
<script src="<?php echo e(my_asset('lib/jquery-2.1.4.min.js')); ?>"></script>
<script src="<?php echo e(my_asset('lib/popper.min.js')); ?>"></script>
<script src="<?php echo e(my_asset('lib/bootstrap-4/js/bootstrap.min.js')); ?>"></script>
<script src="<?php echo e(my_asset('lib/notify.js')); ?>"></script>
<?php echo $__env->yieldContent('script'); ?>
</body>
</html>    	
