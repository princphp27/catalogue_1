<?php $__env->startSection('pageTitle','Sub Categories'); ?>
<?php $__env->startSection('content'); ?>
<div class="col-xl-12">
	<?php echo $__env->make('client.partials.messages', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	<?php echo $__env->make('client.partials.form-error-messages', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	<div class="card">
		<div class="card-header">Edit</div>
		<div class="card-body">
			<div class="table-responsive">
				<form class="form-horizontal" action="<?php echo e(route('client.sub-categories.update',['id'=>$category->id])); ?>" method="post" enctype= "multipart/form-data">
					<?php echo csrf_field(); ?>

					<input name="_method" type="hidden" value="PUT">

					<table class="table table-bordered" style="width: 100%;">
						<tr>

							<th width="20%">Parent Category:</th>
							<td>
								<select class="form-control" name="parent" placeholder="Select parent category">
									<option value="">---Select---</option>

									<?php $__currentLoopData = $parentCategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pCat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
										<option value="<?php echo e($pCat->id); ?>" <?php echo e(($category->parent == $pCat->id)?"SELECTED":""); ?>><?php echo e($pCat->name); ?></option>
									<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							  </select>
							</td>
						</tr>
						<tr>

							<th>Sub Category Name:</th>

							<td>
								<input type="text" class="form-control" id="name" name="name" placeholder="Enter category name" value="<?php echo e($category->name); ?>">
							</td>
						</tr>
												
						<tr>
							<th>Description:</th>
							<td>
								<textarea class="form-control" id="description" name="description" placeholder="Description"><?php echo e(old('description',$category->description)); ?></textarea>
							</td>
						</tr>
						<?php
						$status = old('status',$category->status);
						?>
						<tr>
							<th>Status:</th>
							<td>
								<label class="radio-inline"><input type="radio" name="status" value="1" checked="checked"> Active</label>
								<label class="radio-inline"><input type="radio" name="status" value="0" <?php if($status=='0'){ echo 'checked="checked"';}?>> Inactive</label>
							</td>
						</tr>
						<tr>
							<th>Image:</th>
							<td>
								<img src="<?php echo e(my_asset('storage/uploads/category_images')); ?>/<?php echo e(($category->image)); ?>" width="150px" height="100px"/>
								<input type="file" class="form-control" id="image" name="image" placeholder="Select image file">
							</td>
						</tr>
						<tr>
							<th>Banners:</th>
							<td>
	
								<?php
								$banners = $category->getBanners;
								?>
								<?php if($banners): ?>
									<?php $__currentLoopData = $banners; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $banner): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
										<div class="category-banner-container">
											<img src="<?php echo e(my_asset('storage/uploads/category_banners')); ?>/<?php echo e(($banner->image)); ?>" ="150px" height="100px"/></div>
									<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
								<?php endif; ?>
								<input type="file" class="form-control" name="banners[]" placeholder="Select banners" multiple>
							</td>
						</tr>
						<tr>
							<th></th>
							<td>
								<button type="submit" class="btn btn-primary">Save</button>
							</td>
						</tr>
					</table>
				</form>
			</div>
		</div>	
	</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('client.layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>