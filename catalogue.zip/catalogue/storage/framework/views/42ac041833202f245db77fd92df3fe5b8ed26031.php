<?php $__env->startSection('pageTitle','Settings'); ?>
<?php $__env->startSection('content'); ?>
<div class="col-xl-12">
	<?php echo $__env->make('client.partials.messages', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	<?php echo $__env->make('client.partials.form-error-messages', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	<div class="card">
		<div class="card-header">Theme</div>
			<div class="card-body">
				<div class="table-responsive">
					<table class="table table-bordered" style="width: 100%;">
						<tr>
							<th width="20%">Color Code:</th>
							<td><?php echo e(($dataInfo) ? $dataInfo->color_code : "N/A"); ?></td>
						</tr>
						<tr>
							<th></th>
							<td>
								<a href="<?php echo e(route('client.theme.edit')); ?>" class="btn btn-primary">Edit</a>
							</td>
						</tr>	
					</table>
				</div>
			</div>
		</div>	
	</div> 
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('client.layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>