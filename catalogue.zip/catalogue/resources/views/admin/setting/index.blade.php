@extends('admin.layouts.adminApp')
@section('pageTitle','Settings')
@section('content')
<div class="col-xl-12">
@include ('admin.partials.messages')
@include ('admin.partials.form-error-messages')
	<div class="card">	
		
	</div> 
</div>
@endsection