@extends('admin.layouts.adminApp')
@section('pageTitle','Dashboard')
@section('content')
	
@endsection

@section('script')
@endsection