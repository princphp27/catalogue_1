-- phpMyAdmin SQL Dump
-- version 4.8.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 27, 2018 at 12:58 PM
-- Server version: 10.1.32-MariaDB
-- PHP Version: 7.2.5

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `cms_catalogue`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbl_admins`
--

CREATE TABLE `tbl_admins` (
  `id` int(11) NOT NULL,
  `first_name` varchar(100) NOT NULL,
  `last_name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `profile_image` varchar(100) NOT NULL,
  `api_token` varchar(100) NOT NULL,
  `remember_token` varchar(100) DEFAULT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tbl_admins`
--

INSERT INTO `tbl_admins` (`id`, `first_name`, `last_name`, `email`, `password`, `profile_image`, `api_token`, `remember_token`, `status`, `created_at`, `updated_at`) VALUES
(1, 'Talib Aziz', 'Admin', 'admin@gmail.com', '$2y$10$DT3FJuvMvWhBFg0k19N.aunkUlIxiH8seyHNHgWvHs1NQnACOLevG', '1532688974.jpg', 'MybL5lsZXXkoL8TAvGvLALdRgizCJdt9sb5z0meTCRCVuRxHp0oHgUG1MTWq', '6eoPqYPgRjz9k7FYc13uWaYjCG7oKKywkfImUt1Qkt4e6G80iYhioIarIgtL', 1, '2018-04-11 10:58:57', '2018-07-27 10:56:14');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_categories`
--

CREATE TABLE `tbl_categories` (
  `id` int(11) NOT NULL,
  `client_id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `image` varchar(100) NOT NULL,
  `parent` int(11) NOT NULL DEFAULT '0',
  `description` text,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tbl_categories`
--

INSERT INTO `tbl_categories` (`id`, `client_id`, `name`, `image`, `parent`, `description`, `created_at`, `updated_at`, `status`) VALUES
(4, 1, 'Cyber Category 1', 'Z4BscD9xTXGpVP6czJOniOf2QPqJVqXUcUVhl6GQlOBxhZXhYQf4yUscJaKt.png', 0, 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.', '2018-05-14 02:30:13', '2018-05-14 08:00:13', 1),
(5, 1, 'Cyber Category 2', 'FTMEDB1Pe368WbbPfAW8nmunteocEpoCvltowEOcUSDEPMANcmDZhVpldHk7.jpg', 0, 'Cyber Category 2 description', '2018-05-16 07:48:33', '2018-05-16 13:18:33', 1),
(10, 1, 'vbhfgh', '1531482678.jpg', 3, NULL, '2018-07-09 07:43:25', '2018-07-13 11:51:18', 1),
(17, 2, 'computer hardware', '1531563346.jpg', 0, 'electronic goods', '2018-07-09 23:32:23', '2018-07-14 10:15:46', 1),
(54, 2, 'pankaj1@gmail.com888', '1531229775.jpg', 17, NULL, '2018-07-10 08:06:15', '2018-07-10 13:36:15', 1),
(55, 1, 'pankaj5465656', '1531292823.jpg', 17, NULL, '2018-07-11 01:37:03', '2018-07-11 07:07:03', 1),
(56, 2, 'fddfgdfg', '1531292850.jpg', 5, NULL, '2018-07-11 01:37:30', '2018-07-11 07:07:30', 1),
(58, 1, 'computer software', '1531292994.jpg', 0, NULL, '2018-07-11 01:39:54', '2018-07-11 07:09:54', 1),
(59, 2, 'shubham', 'NTDGrQ3wAnSbKKPmKzVo37xOj9jwLtMhlN6OB4QCwBW6V5glKfY5MG3hl32v.jpg', 17, 'ewfefwef', '2018-07-11 04:16:57', '2018-07-11 09:46:57', 1),
(64, 1, 'window software', '1531472343.jpg', 58, NULL, '2018-07-13 03:29:03', '2018-07-13 08:59:03', 1),
(110, 7, 'auto', '1532682750.jpg', 0, NULL, '2018-07-27 03:42:30', '2018-07-27 09:12:30', 1),
(111, 7, 'four wheeler', '1532682797.jpg', 110, NULL, '2018-07-27 03:43:17', '2018-07-27 09:13:17', 1),
(112, 7, 'for wheeler', '1532682883.jpg', 110, NULL, '2018-07-27 03:44:43', '2018-07-27 09:14:43', 1),
(115, 7, 'nano parts', 'ywS91uvt75UXBk21CbJ9wQzsVArJGzh6vtYoqztv34rEBXEoRwJUEvcZHbXY.jpg', 110, 'djfg djfgjds', '2018-07-27 04:05:07', '2018-07-27 09:35:07', 1);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_category_banners`
--

CREATE TABLE `tbl_category_banners` (
  `id` int(11) NOT NULL,
  `client_id` int(11) NOT NULL,
  `category_id` int(11) NOT NULL,
  `image` varchar(250) NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tbl_category_banners`
--

INSERT INTO `tbl_category_banners` (`id`, `client_id`, `category_id`, `image`, `status`, `created_at`, `updated_at`) VALUES
(1, 1, 5, 'czvkx17TshScLrSusSZ6jaCPduN9WHjNQpwrGPpXij5sz432v1JOlm6TCOij.png', 1, '2018-05-16 07:51:57', '2018-05-16 13:21:57'),
(2, 1, 5, 'R9VFQQ5BD3gmStsKKa9fvIeVwsLh0TU9OHwfqyTtCFRJgyi03B1DDWnkxVtg.png', 1, '2018-05-16 07:51:57', '2018-05-16 13:21:57'),
(3, 1, 5, 'BLrjARiYwFlYgnn4VDcU08MaaieOT9b6nELDBVh5OSOiKZ0wcheV7Ejc9J9c.png', 1, '2018-05-16 07:51:57', '2018-05-16 13:21:57'),
(4, 1, 5, 'KveWXSVuOFQkOmyDemV6d1Pa1P5lYvSYFfmcS4pjKXmXVcHsnhSAsewBSImk.jpg', 1, '2018-05-16 07:51:57', '2018-05-16 13:21:57'),
(5, 1, 6, 'S5DwbgwudKz7CjC5jytA6I3nJwhVFOq6q45midciLuVZWiSzgemeVRE3W5t7.png', 1, '2018-05-16 07:58:32', '2018-05-16 13:28:32'),
(6, 1, 6, 'wafhtN7z3Mc5d0G85804UXingbsrwOJr1HF80cjZVHVuUz7iCdSTpFtgXfo0.jpg', 1, '2018-05-16 07:58:32', '2018-05-16 13:28:32'),
(7, 1, 6, 'u1oAhj6vPRKpoZgPxiPUTkkPRLgGhvd7107PcMPduy0XWLckfkfrpEl20Irg.png', 1, '2018-05-16 07:58:44', '2018-05-16 13:28:44'),
(8, 1, 7, 'ovTi5zJDMwCgpmLgNNhs7tOhagHNKtO1SIlYIjPV8GFUt4noA9zE8LL4H2fD.png', 1, '2018-05-16 08:00:26', '2018-05-16 13:30:26'),
(9, 1, 7, '1SHyLzDKgp9LEMSiTsOfmien7QS6wLUMpEFL3bhSGGvJ0GR1BRjbaQc8Is7N.png', 1, '2018-05-16 08:00:26', '2018-05-16 13:30:26'),
(10, 1, 7, '1Z8MzNWCRt3xt3BLXkSQSZT8yeukrbQmKJQMLwRkDTZnSLDzcezGqGpkUZiC.png', 1, '2018-05-16 08:00:26', '2018-05-16 13:30:26'),
(11, 1, 7, 'yeRCeiJXVyx7tteU3JuWqJJENeCsWshdjpPA5J3ecBB6QR9cJ60JYMcDKl6U.jpg', 1, '2018-05-16 08:00:26', '2018-05-16 13:30:26'),
(12, 1, 7, 'z3cjN1RBDW7LJckTQWA8kX5BbGEU1FEGjbte8XySGx1tBqcDiR6diGhS2oAo.jpg', 1, '2018-05-16 08:01:07', '2018-05-16 13:31:07'),
(13, 1, 4, 'p6ggCTd2CCxcqBYBVm8SfBHUauwtAxpDVHG07VtvIjFqcmwCExkYl3ZgwmYf.png', 1, '2018-05-16 10:18:33', '2018-05-16 15:48:33'),
(14, 1, 6, 'vmABh2gG6AkfHegCxjQcYwuNjaklGpWsb6u7JUWyhcp8W7xOwx2YvYynqty4.jpg', 1, '2018-07-09 04:20:44', '2018-07-09 09:50:44'),
(15, 1, 7, 'JAMt4RNWp8KyGiIpanCvxRawaH66cNTJ5YHJ5idF66Q0UbqbLEB9pbcG8SNc.jpg', 1, '2018-07-09 04:25:55', '2018-07-09 09:55:55'),
(16, 1, 8, 'ukzDLDy14ESKAzkydvPf8EdLdGBtCdkQjrdT0BN86YnOkJBgpdhPJD33bfQ1.jpg', 1, '2018-07-09 04:26:09', '2018-07-09 09:56:09'),
(17, 1, 9, 'rFV79BM6MoifKKqRbf9IMXzBSJHOECRiPXxO6Y0fFMjJw4ezvCjh1E3wKLsd.jpg', 1, '2018-07-09 07:13:29', '2018-07-09 12:43:29'),
(18, 1, 15, 'pbyaZ1CAobpyrAjYLfXbcISVZzmZ2PiYffYqFQLLYY6qTeBPXbE8gSXRlgrB.jpg', 1, '2018-07-09 23:28:20', '2018-07-10 04:58:20'),
(19, 1, 16, 'C2tLl0IAFOirjTs7267N5Y54ELSAou2HwAcFAEXwVVtsbOgI67I0SXdLDxw1.jpg', 1, '2018-07-09 23:29:00', '2018-07-10 04:59:00'),
(20, 2, 17, 'UK1oINxRIJXyM222qcNelLYfTY2cPCKYgADRSAGLUDJcQXsTTSauOYUzzxYc.jpg', 1, '2018-07-09 23:32:23', '2018-07-10 05:02:23'),
(21, 2, 18, 'bZCFJBqGlArxxoc8cusSbJ2RKOVYK7Jwp3699X3PQtVOaBDrxeIrK0ncuLbg.jpg', 1, '2018-07-09 23:33:14', '2018-07-10 05:03:14'),
(22, 2, 29, 'LD6dnOL67cTY0cNqlcM3ossNZvHsc2tnrbO3vHf39dqZfXQunEOjsI4Q6JYT.jpg', 1, '2018-07-10 04:44:30', '2018-07-10 10:14:30'),
(23, 2, 32, '9KCLQ3eiIh2pbiTocbd5zivlUdk7vv7qqFXvkdmUAZHtFdZhOYgeeQtQpnLZ.jpg', 1, '2018-07-10 05:50:48', '2018-07-10 11:20:48'),
(24, 2, 33, '8uOnQB8PAy77E0cG7cDqsLTLAsroo2DiRM6yxvK35iTUQhaR4KHgGdTOZvgG.jpg', 1, '2018-07-10 05:51:16', '2018-07-10 11:21:16'),
(25, 2, 59, 'b03iKIm3DZv6YuEfuqpAU3K9lE0GjytLMtcEVoXjgMR83OJwOYN8B0NCASM5.jpg', 1, '2018-07-11 04:16:57', '2018-07-11 09:46:57'),
(26, 2, 60, 'AWHcY1j5lXoqn8lxWYC002K04AS2I8cq49GJ5rhn9RpOLuPK4MHXEP6WccpL.jpg', 1, '2018-07-11 04:18:46', '2018-07-11 09:48:46'),
(27, 1, 62, 'yXpPPSl17Q63yEfRxEqWmhNcPeaLCYcWXIxfmlf83bZzHDMLA1fT9fx6LAJ2.jpg', 1, '2018-07-12 06:29:42', '2018-07-12 11:59:42'),
(28, 1, 63, 'TywCwWt5XH15iuivbMk5CeTXFa7pwvme5UMjJMqz1c2CQ0Xr6JqSYRnDoJqw.jpg', 1, '2018-07-13 01:43:07', '2018-07-13 07:13:07'),
(29, 3, 74, '8OrNTzsefcqZohSRetOD9t23q0NjKLTmbL5x1CeQRylY35ilxElEMjG7BnlG.jpg', 1, '2018-07-16 01:40:52', '2018-07-16 07:10:52'),
(30, 3, 75, 'dBmqXTVXKTI5PgumUrcrkbXkrklykeAdPXyg1g2OyyPRpPJLxA0R1xjL4EJr.jpg', 1, '2018-07-16 02:03:11', '2018-07-16 07:33:11'),
(31, 3, 77, 'j1b1wcOTv7TYJDoBydNDbKtybvryfTNXrQABjPTKtvnFkVJanglFTeM4ZBxx.jpg', 1, '2018-07-16 02:12:16', '2018-07-16 07:42:16'),
(32, 3, 79, 'yfRjyhcfRckyxtya0GF1rrMlrSDpjzbOFqFbCrOKNfcAze1gNwMwRzwAOJVp.jpg', 1, '2018-07-16 03:35:48', '2018-07-16 09:05:48'),
(33, 3, 80, 'p0mPWNcsUBBfBOKiPOJgxhhuLRJgaLxHhpis4nYnkfn2afEt43Z0kqTtyYfj.jpg', 1, '2018-07-16 03:36:54', '2018-07-16 09:06:54'),
(34, 4, 86, 'd3usX0DQtFqNnKyvt3b4YHOdXd6n8Th9wyXNE1Z1EAFAi0mly6b4L2kOCiqB.jpg', 1, '2018-07-16 05:28:55', '2018-07-16 10:58:55'),
(35, 4, 87, 'wpZW50vwH5ctckARCWHlHBtMLVKd1REMhUErqLSJWgbhXpIDyw8FZlywjRYT.jpg', 1, '2018-07-16 05:32:22', '2018-07-16 11:02:22'),
(36, 3, 88, 'hrjcdtz43UTyvSjQGuG1VHSJb1MnOjBx7Y0ezxauvc6kxQXIQw4KjWxiTtqb.jpg', 1, '2018-07-16 06:35:08', '2018-07-16 12:05:08'),
(37, 4, 89, '8JGMolBeUCoxyLzZJcoGm3od0PsgLWtfI5mCRY3F1F9kfGXImf85dUm7f6iT.jpg', 1, '2018-07-16 06:41:57', '2018-07-16 12:11:57'),
(38, 4, 90, 'nPmtW9Qqon92UqlgGsBVi5DFQJlAG640BHV0xMcIYSaZDz6EqFJiBOKTXljD.jpg', 1, '2018-07-16 06:44:09', '2018-07-16 12:14:09'),
(39, 6, 97, 'jItVmueKd1Se2DuRwcvhwE2xgSYfi0ENFaq5VbxYxdtjCsApXKwa33Dh7NjS.jpg', 1, '2018-07-16 08:25:34', '2018-07-16 13:55:34'),
(40, 6, 98, 'YF8jaEfYiV7Na6nB7tOt0gGA80pk0repsjs84XMhLGcF7e4Ead1uFRYSKfj3.jpg', 1, '2018-07-16 08:26:22', '2018-07-16 13:56:22'),
(41, 4, 100, 't8hqj7cwxOFpdBFQJHqO6a97GM9cguNRTrvv3HSNADY8XeSFmH8NY8ElTqtw.jpg', 1, '2018-07-16 08:36:58', '2018-07-16 14:06:58'),
(42, 4, 101, 'HSs4ZhQMAWa207wY3pAc9b0anSkGNCdMg6ac1goNpZl3a7JZlkiYj4MiMtEY.jpg', 1, '2018-07-16 08:37:38', '2018-07-16 14:07:38'),
(43, 3, 102, '4Q3VpOfePzWuzk8lgcMJFn1NysZvWcq90wuOiHkoPRfqLX5j8AN0C5EmTL51.jpg', 1, '2018-07-17 08:23:08', '2018-07-17 13:53:08'),
(44, 3, 103, 'LOk2QFhluouvz6ZQcEHEiys6DWmZcp3Dq1eg2wMtyQMg1xpl7YUm9wYlwnV9.jpg', 1, '2018-07-17 08:27:47', '2018-07-17 13:57:47'),
(45, 3, 104, 'KbUtHzVydi1kYbuoMHoVYb82PjPrgGl2PTtnkxiRSPuyhQerjiqKprlO4zug.jpg', 1, '2018-07-17 08:35:47', '2018-07-17 14:05:47'),
(46, 3, 105, 'wPul6kR6jTN4LX2XkNe4X6lIPaU7txbF5x1Ght4JK2VUs7LBctnw4CpSWPGy.jpg', 1, '2018-07-17 08:36:15', '2018-07-17 14:06:15'),
(47, 3, 106, 'YDtA6znVaOsvXnXlE4ZshQGU2BvN8It3NfbtCY1mVMrn6e3dCXzkDiFAjop8.jpg', 1, '2018-07-17 23:13:12', '2018-07-18 04:43:12'),
(48, 3, 107, 'qZNqUmdkn06n7BVBIjhk7Lvu5coY1cAYbCVJO7di47yACO7TP68BfgbtH5Ou.jpg', 1, '2018-07-17 23:14:18', '2018-07-18 04:44:18'),
(49, 3, 108, 'oxHbRZ4xg42kTOINabdNatkuPQ3Rr55LforDZCXpr7yJ0VYuTHBXtpqGXAeq.jpg', 1, '2018-07-17 23:14:48', '2018-07-18 04:44:48'),
(50, 3, 109, '6UxFees9j0aGtbY9DqV0aFdRkDwts2kdb3yTJDcHzPhCuNOaxIiY0HTZUwng.jpg', 1, '2018-07-19 01:47:53', '2018-07-19 07:17:53'),
(51, 7, 113, '5d2YfCUZfnpr0mugR3fsmsFRbehaV71WOX7X2GYpMd8YzxbldE6LiIqdFzT9.jpg', 1, '2018-07-27 03:48:26', '2018-07-27 09:18:26'),
(52, 7, 114, 'rQItfr2enRzgxf9AXSuHpV4vfowI4Iw4AY8gmEYV0wXwQrFk6jI6FWO7hqfW.jpg', 1, '2018-07-27 04:04:02', '2018-07-27 09:34:02'),
(53, 7, 115, 'RXlAjGYstXDNlxni7PiVQYyrSDT0aTtu3h6K5Ie07pevHClNaJmdgceaFMjM.jpg', 1, '2018-07-27 04:05:07', '2018-07-27 09:35:07'),
(54, 7, 116, '3X6xr54Z9TWp5BVhjYh3gRA9t4EtlApy1nzCqoWnmhpnOvCXpkLhT2lHP0aE.jpg', 1, '2018-07-27 05:15:42', '2018-07-27 10:45:42'),
(55, 7, 117, '2OojK0bfo1NQyEnWDkr8jYY7j7TSADGWdwqsQiYsSBl37RwTdyL4sArgUiSg.jpg', 1, '2018-07-27 05:17:34', '2018-07-27 10:47:34');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_clients`
--

CREATE TABLE `tbl_clients` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `address` varchar(100) NOT NULL,
  `city` varchar(20) DEFAULT NULL,
  `state` varchar(20) DEFAULT NULL,
  `pincode` varchar(20) DEFAULT NULL,
  `logo` varchar(100) DEFAULT NULL,
  `description` text,
  `phone` varchar(20) NOT NULL,
  `contact_name` varchar(50) NOT NULL,
  `contact_mobile` varchar(20) NOT NULL,
  `contact_email` varchar(100) NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT NULL,
  `token` varchar(100) NOT NULL,
  `is_delected` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tbl_clients`
--

INSERT INTO `tbl_clients` (`id`, `name`, `email`, `address`, `city`, `state`, `pincode`, `logo`, `description`, `phone`, `contact_name`, `contact_mobile`, `contact_email`, `status`, `created_at`, `updated_at`, `token`, `is_delected`) VALUES
(1, 'CyberMatrix', 'cyber@gmail.com', 'Sector-2', 'Noida', 'UP', '98347938', NULL, 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.', '88797', 'Talib Aziz', '9310362940', 'talib@gmail.com', 1, '2018-05-11 13:44:56', '2018-05-11 13:44:56', 'ZqPQiqB0jR5ED4T6rf6JTWUD5cKWp1TcmGvUaelYRdtxGQwQqf5VvLYltA8C', 0),
(2, 'Hero Honda', 'herohonda@gmail.com', 'New Delhi', 'New Delhi', 'Delhi', '110001', NULL, 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.', '8876878', 'TaliB', '9310362940', 'talib@gmail.com', 1, '2018-05-14 08:20:21', '2018-05-14 08:20:21', 'GJeNjRG2C8VYCha8YbJ72u22KcKB9sATz4hMEKNnNEI2m7DCf2AD9ue7rRYs', 0),
(7, 'shubham patel', 'shubham@mail.com', 'gwalior', 'gwalior', 'mp', '474003', NULL, 'ddddd', '8827950286', 'shubham', '8827950286', 'shubham@mail.com', 1, '2018-07-16 10:10:42', '2018-07-27 08:56:14', '2nd9xErkS7RpDc2yoimOaW9q6n2uC0R0DwmQCGIvtWATGhHGA221N3WVPg4E', 0);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_customers`
--

CREATE TABLE `tbl_customers` (
  `id` int(11) NOT NULL,
  `token` varchar(100) NOT NULL,
  `client_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `first_name` varchar(50) NOT NULL,
  `last_name` varchar(50) DEFAULT NULL,
  `gender` varchar(10) DEFAULT NULL,
  `address` varchar(100) DEFAULT NULL,
  `city` varchar(20) DEFAULT NULL,
  `state` varchar(20) DEFAULT NULL,
  `pincode` varchar(10) DEFAULT NULL,
  `mobile` varchar(20) DEFAULT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_enquiries`
--

CREATE TABLE `tbl_enquiries` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `client_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `subject` varchar(255) NOT NULL,
  `message` text,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_migrations`
--

CREATE TABLE `tbl_migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `tbl_migrations`
--

INSERT INTO `tbl_migrations` (`id`, `migration`, `batch`) VALUES
(5, '2014_10_12_000000_create_users_table', 1),
(6, '2014_10_12_100000_create_password_resets_table', 1);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_password_resets`
--

CREATE TABLE `tbl_password_resets` (
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_products`
--

CREATE TABLE `tbl_products` (
  `id` int(11) NOT NULL,
  `client_id` int(11) NOT NULL,
  `category_id` int(11) NOT NULL,
  `name` varchar(250) NOT NULL,
  `description` text,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT NULL,
  `product_main_image` varchar(250) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tbl_products`
--

INSERT INTO `tbl_products` (`id`, `client_id`, `category_id`, `name`, `description`, `status`, `created_at`, `updated_at`, `product_main_image`) VALUES
(4, 1, 4, 'My New Product', 'My New Product descriptions', 1, '2018-05-16 14:55:08', '2018-05-16 14:55:08', NULL),
(6, 2, 54, 'pankaj', 'rfrf', 1, '2018-07-11 11:36:15', '2018-07-11 11:36:15', NULL),
(10, 2, 59, 'pankaj11@gmail.com', 'vsdvg', 1, '2018-07-12 07:11:09', '2018-07-12 07:11:09', NULL),
(14, 1, 5, 'shubham456989', 'Test Description', 1, '2018-07-12 13:52:12', '2018-07-12 13:52:12', NULL),
(15, 1, 17, 'shubham456989', 'Test Description', 1, '2018-07-12 13:53:00', '2018-07-12 13:53:00', NULL),
(17, 1, 77, 'mouses', 'pointing device', 1, '2018-07-12 14:03:57', '2018-07-16 09:01:21', NULL),
(19, 1, 111, 'os', 'dfg', 1, '2018-07-12 14:12:12', '2018-07-27 09:16:38', NULL),
(20, 1, 17, 'keyboard', 'jfdjdgj', 1, '2018-07-12 14:14:18', '2018-07-12 14:14:18', NULL),
(24, 1, 58, 'wifi driver', 'fgfhgfhgh', 1, '2018-07-13 05:01:56', '2018-07-13 05:01:56', NULL),
(25, 1, 64, 'window 8', 'dvdfv', 1, '2018-07-13 09:07:26', '2018-07-13 09:07:26', NULL),
(26, 1, 64, 'pankaj', '6876896', 1, '2018-07-16 08:24:28', '2018-07-16 08:24:28', NULL),
(27, 1, 77, '6flsdlfcndlnl', 'dsbcjd dsgdj', 1, '2018-07-16 08:25:21', '2018-07-16 08:25:21', NULL),
(28, 1, 75, 'for business investment', 'fnv,fdv, mdbvmdf kbfvkf', 1, '2018-07-16 08:47:22', '2018-07-16 08:47:22', NULL),
(30, 3, 75, 'for business testing', 'cnhggjghj', 1, '2018-07-16 09:03:34', '2018-07-16 09:03:34', NULL),
(32, 4, 85, 'product name is required', 'djvcjdf djcvjdv', 1, '2018-07-16 10:56:30', '2018-07-16 10:56:30', NULL),
(33, 4, 83, 'testing purpose', 'bvdbvf jkbvfbfjkv', 1, '2018-07-16 11:01:09', '2018-07-16 11:01:09', NULL),
(34, 4, 83, 'tessting error', 'dfgff', 1, '2018-07-16 12:42:24', '2018-07-16 12:42:24', NULL),
(35, 4, 84, 'tessting error', 'dfgff', 1, '2018-07-16 12:44:31', '2018-07-16 12:44:31', NULL),
(36, 4, 85, 'test anyrhing', 'dfgresdvgfv', 1, '2018-07-16 12:53:21', '2018-07-16 12:53:21', NULL),
(37, 4, 83, 'for mobile', 'htfghtrh', 1, '2018-07-16 12:54:44', '2018-07-16 12:54:44', NULL),
(38, 6, 96, 'laptop testing', 'this test is done on the driver', 1, '2018-07-16 13:52:47', '2018-07-16 13:52:47', NULL),
(39, 6, 96, 'laptop driver', 'this vkfnkvfn', 1, '2018-07-16 13:54:00', '2018-07-16 13:54:00', NULL),
(40, 4, 99, 'abc', 'h', 1, '2018-07-16 14:05:23', '2018-07-16 14:05:23', NULL),
(41, 4, 101, 'pankaj', 'jjj', 1, '2018-07-16 14:08:38', '2018-07-16 14:08:38', NULL),
(42, 3, 88, 'for investment', 'this test', 1, '2018-07-17 05:23:08', '2018-07-17 05:23:08', NULL),
(43, 7, 112, 'seat tiers', 'test data', 1, '2018-07-27 09:15:46', '2018-07-27 09:15:46', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_product_banners`
--

CREATE TABLE `tbl_product_banners` (
  `id` int(11) NOT NULL,
  `client_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `image` varchar(250) NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tbl_product_banners`
--

INSERT INTO `tbl_product_banners` (`id`, `client_id`, `product_id`, `image`, `status`, `created_at`, `updated_at`) VALUES
(1, 1, 2, '49xXP9C3HAo5qEkyro9puuINaHnQPi6x7edCIPYa8VgQKPMXW3DwmDOzC17S.png', 1, '2018-05-16 12:41:35', '2018-05-16 12:41:35'),
(2, 1, 2, 'UCsGZKeJUMxOdS1j2IFyTtEUpTZr2mypxUKxvnMmijsrchUEkqxRH5B8t2nY.png', 1, '2018-05-16 12:41:35', '2018-05-16 12:41:35'),
(3, 1, 3, 'fuvB4Fx662z6m4mbCzA70BpDJrK6EwYs57BkCx7jV6XxRZ9WzX8h5iMqtRLT.png', 1, '2018-05-16 12:44:34', '2018-05-16 12:44:34'),
(4, 1, 3, '3EJ2BN24G8UoRLuSFRWvOHjPuq8uLgpQf6c6Xn7VAuXTww73DLpo1rGqP5ui.jpg', 1, '2018-05-16 12:44:34', '2018-05-16 12:44:34'),
(5, 1, 3, 'ZvmTFNyPxZJtNR8OVnx3BVxIRATgY4eHWN0QxE07OSJqcOLkbfhbzNESqnzW.png', 1, '2018-05-16 12:47:04', '2018-05-16 12:47:04'),
(6, 1, 4, '3scegLZyy3HZ9cjzQmsU4PevWZxhEenE6rvfMgJuWx2XBgsSTXSFLBVN9Jlz.png', 1, '2018-05-16 14:55:08', '2018-05-16 14:55:08'),
(7, 1, 4, 'AQgsMn8svN05oLWkvRdNS65ocTliZGIBs30kZOHegHCPIUqUbmgF7CFjwdZg.jpg', 1, '2018-05-16 14:55:08', '2018-05-16 14:55:08'),
(8, 1, 4, '5yuf1ed8Kedgd4OV9WCDAVKbHSTVPu8dGOAja3j8CA5Sf5RFZUS9OwKlZ5GK.png', 1, '2018-05-16 15:43:17', '2018-05-16 15:43:17'),
(9, 1, 5, 'yNlaxaWNVOM0oFVdcb6k3Rm0T9HFcYHJzJ6cRhhH1QKwCLgQFWCbGTHqxIw8.png', 1, '2018-05-17 06:34:28', '2018-05-17 06:34:28'),
(10, 1, 5, 'GKg3hlLBQgYnlyN8CGPgIiQCO9RdRnxdxV9Fmqw8W2fMSX8RuzBJ5Jai37L0.jpg', 1, '2018-05-17 06:34:28', '2018-05-17 06:34:28'),
(11, 2, 6, 'vyrTs343uDBeIZ8Eei9MBe7NiN4r6GqzmAtP0PD2HtMnjbadvlTnYFAd9zRl.jpg', 1, '2018-07-11 11:36:15', '2018-07-11 11:36:15'),
(12, 1, 7, '97JkrC0jDl5VFGt8i8gJ5FoCqH4dPra9XLgoEdpr97K9s2Xw9sFu5CxjuSfX.jpg', 1, '2018-07-11 11:54:55', '2018-07-11 11:54:55'),
(13, 1, 8, 'M0HpbEzm1ecAz2Y7I2hn3FcqZjZg5baWDWXXs3AImivztFz5XBVu4rpQzuSv.jpg', 1, '2018-07-11 12:21:41', '2018-07-11 12:21:41'),
(14, 1, 8, '2ktxuHheZzMQXuyteQDo3sDZT4WHJG6ntJuJZzgbnYGN9OeDuatyPwtaUzJx.jpg', 1, '2018-07-12 06:05:55', '2018-07-12 06:05:55'),
(15, 1, 11, 'fDNwLf0tFLJtI8KBy6JYZuUzJ1oaw1NNFF378eTmUEmRQ8TZI1KD2hnrkZzi.jpg', 1, '2018-07-12 13:38:29', '2018-07-12 13:38:29'),
(16, 1, 14, 'sZ8lruk6DTPZuSOT6GlIS0ZupE6TVURKcUSNGwgSBcHLolg8Tb5cXDa0D8jN.jpg', 1, '2018-07-12 13:52:13', '2018-07-12 13:52:13'),
(17, 1, 15, 'BLp7a1LOINpXs9fdCqEGUiyklmAFYp2xI4AfbbfXlrdM8KgU8awXHgbxjYh9.jpg', 1, '2018-07-12 13:53:01', '2018-07-12 13:53:01'),
(18, 1, 16, 'GcCF2PZpAhtkksd20gJAqc6BTxumP2OOvgmrOdHTVJN3YRQMimIgf8hrHWEz.jpg', 1, '2018-07-12 13:59:03', '2018-07-12 13:59:03'),
(19, 1, 17, 'JlZva11TlesZeaII7IWnTMBkG3QZAmOG2ZOMUgWzovqK3yfsWI2mIYcEApnX.jpg', 1, '2018-07-12 14:03:59', '2018-07-12 14:03:59'),
(20, 1, 18, '7mrZYLtSsQtyLmOs60waYj0YT64yJHK3S8MK25UGEuoKfWubxBp7gGr5JZRQ.jpg', 1, '2018-07-12 14:06:20', '2018-07-12 14:06:20'),
(21, 1, 19, 'pxYkXXAgXQNQmzSGyzWZ9FfCh73bnTcK3P0KHobtIATnDmsaMmCYn3ui1VVK.jpg', 1, '2018-07-12 14:12:13', '2018-07-12 14:12:13'),
(22, 1, 20, 'XTAdG8Vxk1aZb63U025tNYUw6Izb1w5nGf2fXMOAilPyGoJDqdT6zUr1ux40.jpg', 1, '2018-07-12 14:14:18', '2018-07-12 14:14:18'),
(23, 1, 5, 'S8ZyOLc8pEsTkjDBX2wwxd8J159xGSanlahTd55HB3DuRmwUjN4iCIc9PEWU.jpg', 1, '2018-07-13 06:57:39', '2018-07-13 06:57:39'),
(24, 1, 25, 'yThWTL2gCbL9tEwUqP8pkkW6XJnQUiW6EQpNqkSjNx40Yf1DMgkfYzGeeZZE.jpg', 1, '2018-07-13 09:07:26', '2018-07-13 09:07:26'),
(25, 1, 26, 'QLyGvANqH5iBQaQKRKlQFz4815RLYwD3PlqOLqdl2lRAEJqpbYrBhQY2EMBU.jpg', 1, '2018-07-16 08:24:28', '2018-07-16 08:24:28'),
(26, 1, 27, 'GHiam5r9hnZJbiLVRWy90jRhhW6D3O86EzMn4UQgVvk79ba3Cm9UDz8IGPhw.jpg', 1, '2018-07-16 08:25:21', '2018-07-16 08:25:21'),
(27, 1, 28, 'omZljGVYqHXuzRlzeS4lf1SVhpfC1yBs3vKT9DpVoI54nDG8twnv5cwpL1PR.jpg', 1, '2018-07-16 08:47:23', '2018-07-16 08:47:23'),
(28, 3, 30, 'VS9CftgwoPl3owCLxQvRs3TNOlIiOxCMvhzsJQDU4pDZTfc9ip6vkxQpba5S.jpg', 1, '2018-07-16 09:03:34', '2018-07-16 09:03:34'),
(29, 3, 31, 'JrVyVDgdNB9KV7DcGMLvCnGsyuHcXbWyAG0BIwVdbI54W4VPnuLdnOuY66av.jpg', 1, '2018-07-16 10:05:21', '2018-07-16 10:05:21'),
(30, 4, 32, 'zwMnTTtNg2zzsuJ7SN5mMq3BAO9MBaoQlBxXh9G4MFbONH2x6aSF5SQeM4z6.jpg', 1, '2018-07-16 10:56:30', '2018-07-16 10:56:30'),
(31, 4, 33, 'W7RjvoydWi1bHbOh64PFh2QKVuibbemK9VNfmNc5tgZvkLroTkLJO7cXCWKC.jpg', 1, '2018-07-16 11:01:09', '2018-07-16 11:01:09'),
(32, 6, 34, 'R6E98qACTwP1yY9ZKE9RVQrIQtPKQrAwkEGr4Naf8E9Abgj4O9SngzsdbHhY.jpg', 1, '2018-07-16 12:42:24', '2018-07-16 12:42:24'),
(33, 6, 35, '0OPfAsb6vJ9fKyCyaxu4IOVAuAZ9Udkx9gIxORNyxPjLBN1NzswlVbILCF13.jpg', 1, '2018-07-16 12:44:31', '2018-07-16 12:44:31'),
(34, 4, 36, '0EfZ5PQBep69JULedMjjB74m8nnIPgf2IOttIi5G2j7ucYBquzgGHbcpgd6K.jpg', 1, '2018-07-16 12:53:21', '2018-07-16 12:53:21'),
(35, 4, 37, '0SyF7HBaH1lFjn6THRBRdhLdM4RaiZjSyddats3NfSu0HCGAkfFR6azzVZIJ.jpg', 1, '2018-07-16 12:54:44', '2018-07-16 12:54:44'),
(36, 6, 38, 'DfxDpqQdMND1zw8ajXMHcrQAiKG2qfIZlG0AMnlS0sPOjmpZPWZtmu4J94D0.jpg', 1, '2018-07-16 13:52:47', '2018-07-16 13:52:47'),
(37, 6, 39, 'p7olFbe6IkiCIUvVrzEd19vz6HDWHO7D6GIx156ez2t7LZtwYtuiKH62AZt5.jpg', 1, '2018-07-16 13:54:00', '2018-07-16 13:54:00'),
(38, 4, 40, 'dAy4UHc8279Vd59Ver02ET1dkTsiRkjSzxeSaU2WbMgWtRvj6ylTk0Pntj2J.jpg', 1, '2018-07-16 14:05:24', '2018-07-16 14:05:24'),
(39, 4, 41, '5w6M3vKEm51ECGq3bfTN0b352Kq3nvUTFwD1VxjEsP1mDnoyMz7Z0H9wi5TZ.jpg', 1, '2018-07-16 14:08:39', '2018-07-16 14:08:39'),
(40, 3, 42, 'F2VLwiuCEaDRHjjUNifDVW7quQtqGtG5V3CZ6eQAnuXadO9KaxQaErLzlAxB.jpg', 1, '2018-07-17 05:23:08', '2018-07-17 05:23:08'),
(41, 7, 43, 'BL9VBCVUQC6jwVczLQcTWKyc8LUhWLjXG0edahbPZSS4eqSCi1a0dc3iACiH.jpg', 1, '2018-07-27 09:15:46', '2018-07-27 09:15:46'),
(42, 7, 44, 'F0WWwHzVvRdSLZMWqSbs1d3osjJ4CjcAQ0QE6QiDYdinf49dOu55AZNuQTCT.jpg', 1, '2018-07-27 09:36:20', '2018-07-27 09:36:20'),
(43, 7, 44, 'omtehybaAmf0oT6CQPTWpKo6JyiHfkn4UiHYUZkHF2KyEyrLxsyMLUdQUBno.jpg', 1, '2018-07-27 09:36:59', '2018-07-27 09:36:59');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_product_images`
--

CREATE TABLE `tbl_product_images` (
  `id` int(11) NOT NULL,
  `client_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `image` varchar(250) NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tbl_product_images`
--

INSERT INTO `tbl_product_images` (`id`, `client_id`, `product_id`, `image`, `status`, `created_at`, `updated_at`) VALUES
(1, 1, 1, 'YuRxcJOGVVPKuXs69xHwRpatz9uIItUfaAfF89W99XbZoH2acO1kvgupxKTR.png', 1, '2018-05-16 05:46:22', '2018-05-16 11:16:22'),
(2, 1, 1, 'cfqZImi7ug7tWEYMVt77MA0uQhPnUZjoiHHIruc9ui3Cz6246TpProzMtz5P.png', 1, '2018-05-16 05:46:22', '2018-05-16 11:16:22'),
(3, 1, 1, 'UVAv5KACpJAF304nO0WSlshO7OUSmktXVKvpBkXEPIC4qeYmzU3iMYfFvGFK.png', 1, '2018-05-16 05:46:22', '2018-05-16 11:16:22'),
(4, 1, 1, 'UXP45GZneFmtcFQHNssJKQ3i0ILVHuOUYoQDbOtoKbLyrvJSe7q2adEGcVUv.jpg', 1, '2018-05-16 05:46:23', '2018-05-16 11:16:23'),
(5, 1, 1, 'go977MDm8P6azyhpUH5lPUt59ZcSByFmaJjppWebrwqLH4RjVKh8YsD1mbCi.png', 1, '2018-05-16 06:07:59', '2018-05-16 11:37:59'),
(6, 1, 1, '1nrTOL10NE3QCeVjgYURjVAKpd6Wq0rmbCECY7rgw55Hkd4rMkkJ600peEu4.png', 1, '2018-05-16 06:07:59', '2018-05-16 11:37:59'),
(7, 1, 2, 'ZVQIAqcWr5IUlkLwfDrDyFCQ5MdOsJSrCfPqMVYrw2V9af4vchyyOG5sVjQU.png', 1, '2018-05-16 07:01:34', '2018-05-16 12:31:34'),
(8, 1, 2, 'MLhQzntLzwSrWELP57W3st0taxgSnlBQQyY1GUfh6ton8W3ieQgIW6FaF2cu.png', 1, '2018-05-16 07:01:34', '2018-05-16 12:31:34'),
(9, 1, 2, '8FwsNbZ0Ve2Co5U54xzzoFg4l4RufjDnkL4Ya58VJRbX2dPHx6PJIKeb7yDY.png', 1, '2018-05-16 07:01:34', '2018-05-16 12:31:34'),
(10, 1, 3, '6iVOGbp2LgCQ9zGTQ9CK3iyPUNahrnGFt3bx7EGdd334UcpJ2vPa7flvrLZ3.png', 1, '2018-05-16 07:14:33', '2018-05-16 12:44:33'),
(11, 1, 3, 'lHGo4D2WwjAtnZSUBMnqqV7OfFAyn0Vc5tNV8YSAZx4fYaxUUOt8NFBSmFiP.png', 1, '2018-05-16 07:14:34', '2018-05-16 12:44:34'),
(12, 1, 4, 'O4ZBD8lqWWcponwASYu79GH3WZj4I3AqTrs5WyZWME9gBOU9VViMnDeVV2XI.png', 1, '2018-05-16 09:25:08', '2018-05-16 14:55:08'),
(13, 1, 4, 'jnTuldihc7NNzImvHA2cLklhPfTC3GNTqR3GL7bU2jJ82KlfmFn4LHnGysGQ.png', 1, '2018-05-16 09:25:08', '2018-05-16 14:55:08'),
(14, 1, 5, 'MgXEguD6D5wHcUzHeIUUuFGMB4IbUBnaP3Dr7SN2Pvr66eJAvQUHLeSyMcwp.png', 1, '2018-05-17 01:04:28', '2018-05-17 06:34:28'),
(15, 1, 5, 'etyFAfRA7hKs35IhLcZKqZp9OROhzbTFUXk6Z54UMJmE0hxBbaxnDbeiwJdj.png', 1, '2018-05-17 01:04:28', '2018-05-17 06:34:28'),
(16, 2, 6, 'QHN0eASE1imcdcS9WoxKZMpT8mZ6McnKLxZjbuFSsYzLGuo61WiDJBwYgqk4.jpg', 1, '2018-07-11 06:06:15', '2018-07-11 11:36:15'),
(17, 1, 7, 'mzvQNbSuKkH7VGYhNYPQCIJzrHwwE4yaLU3jkrUZiTWfyAZxc0Ac3ckAqmLa.jpg', 1, '2018-07-11 06:24:55', '2018-07-11 11:54:55'),
(18, 1, 8, 'k8rKEOrxb164vIkXFbXIoZrjvmHGAl376iLZobf8jXK8apvzdytD1S5dA4mI.jpg', 1, '2018-07-11 06:51:41', '2018-07-11 12:21:41'),
(19, 1, 8, 'dBjjnzRg33BY8oJwOcZ755psWUf4WBI3UheKdlrLTyzFpBkloXW7v6LGd455.jpg', 1, '2018-07-12 00:35:55', '2018-07-12 06:05:55'),
(20, 1, 11, 'DjhP8mEF8T3sQp18MNKzubyA6BqV4USpV2IC8WK3wdMQ4ci9JEfBvQPLxmy0.jpg', 1, '2018-07-12 08:08:29', '2018-07-12 13:38:29'),
(21, 1, 14, 'zqLQXroX3kqEv60CMC4AZk2XzjrPtOzjZEHVqwpGQ8ApCaDwG2sXKusV8EYO.jpg', 1, '2018-07-12 08:22:13', '2018-07-12 13:52:13'),
(22, 1, 15, '51zvNvyMKSAhNLRA3y8QYcAtkUAkXBwlM4Mrn9lu7OzVq4XrHESvAnTqyVbx.jpg', 1, '2018-07-12 08:23:01', '2018-07-12 13:53:01'),
(23, 1, 16, 'eKmc5SwivJRTmMi8jGyuORCMXru9JLiZjK7OJOMMMz6XAHitp3k9YlmHIveF.jpg', 1, '2018-07-12 08:29:02', '2018-07-12 13:59:02'),
(24, 1, 17, 'GkZG9O60YOIXl8JuloyKdMYCVF73Nyr05ip2yLY5jZCCeIWfONn98hAbra0d.jpg', 1, '2018-07-12 08:33:59', '2018-07-12 14:03:59'),
(25, 1, 18, 'PCoz1I7SjHa1Bb0xzqohcMZV9SovnIHFMsEpNVmrspWAKPpIusXA2fPHumsn.jpg', 1, '2018-07-12 08:36:19', '2018-07-12 14:06:19'),
(26, 1, 19, '7h8EWpOHvAfx1tdwdgpO6mubEM3v6q7mA4GeF4ovSVSF1fFQn3HcrJxMf3Ie.jpg', 1, '2018-07-12 08:42:12', '2018-07-12 14:12:12'),
(27, 1, 20, 'YwzFtrEE0A2ReNmOr07O0Bq42ENX06UJchDrmTSCh7AesZ4odYvLbyjwg14M.jpg', 1, '2018-07-12 08:44:18', '2018-07-12 14:14:18'),
(28, 1, 5, '3m5XhTiztBO3vxEKTZRhCCmFxc9qGgO5GMAN7pyPMdGp188u7gHygVgBhduk.jpg', 1, '2018-07-13 01:27:39', '2018-07-13 06:57:39'),
(29, 1, 25, 'FNju5QOgvIy2jMczmTOEoAzO0TbzoiKl0MQ8Ea9IqMntUgfAjhUjQlFYuDMD.jpg', 1, '2018-07-13 03:37:26', '2018-07-13 09:07:26'),
(30, 1, 16, 'YvlzzFF23A88TQ4LHI3hIPUsFofOwGFw2nxvKOkDooAdODod9htxTGtITC9C.jpg', 1, '2018-07-14 01:22:04', '2018-07-14 06:52:04'),
(31, 1, 16, 'aNQgsEwC1NnTAL9xFxkBUBjfR7KcbxKd7no9OfjO3QfuxaYZBqXlIvspa4cE.jpg', 1, '2018-07-14 04:40:51', '2018-07-14 10:10:51'),
(32, 1, 26, 'xejQuKhI05YBCrrhA0MqVZS5qKxZ9rpf2QWEIykcBTZKoYZnUzxmUHi9ctiF.jpg', 1, '2018-07-16 02:54:28', '2018-07-16 08:24:28'),
(33, 1, 27, 'V16Vn0tUvl6rns3cuEBB9VYrN5k92Flstq5Dbyq6hURTS3G1O1PEO1P3EQru.jpg', 1, '2018-07-16 02:55:21', '2018-07-16 08:25:21'),
(34, 1, 28, 'q9dgKU9RKHrx6w9UHWlpnwrxHEjRz50KIMC6rOWqhdgbVEQpi6CZFNf0Ws7d.jpg', 1, '2018-07-16 03:17:23', '2018-07-16 08:47:23'),
(35, 1, 17, 'cXv2DUzqEj0KCqT7AEOVovySrABWGyXNt6vZHK7NLe8JTHKqeJxqy7qqnSHE.jpg', 1, '2018-07-16 03:31:21', '2018-07-16 09:01:21'),
(36, 3, 30, 'OylMSm5wnrPnsd8BLRjLJDIq4JOySVjr9nlrs1uxFga2aifvei4lTtHckvN2.jpg', 1, '2018-07-16 03:33:34', '2018-07-16 09:03:34'),
(37, 3, 31, 'junaVdeonNGi58UbGCIletm44Wo4N8HhLc5XrwTo6CtD2thGQ0splwHO6Bt7.jpg', 1, '2018-07-16 04:35:21', '2018-07-16 10:05:21'),
(38, 4, 32, 'ii7NRT28H2yFxwmd2EXjhPHPh5CNEO84sPCqOGuVuZXqAybOOSSHApvMPLwk.jpg', 1, '2018-07-16 05:26:30', '2018-07-16 10:56:30'),
(39, 4, 33, 'GN8eS8kuD1MUokdbRv9g7YjRpo7Ew8LK0xJqftCVKnv5Ri27CzAnzE9oTJRq.jpg', 1, '2018-07-16 05:31:09', '2018-07-16 11:01:09'),
(40, 6, 34, 'vKoq6N4sDBmxpIpniDMEhcFUELs7aPlpSIHlVgYy0U9m8XJ4A2jX7Soom1Ho.jpg', 1, '2018-07-16 07:12:24', '2018-07-16 12:42:24'),
(41, 6, 35, 'DFTGqmSMiosePXtqOO1obBDFk5OQS81VeeUNLiFVGkZFNc5578u5rv8t1bcP.jpg', 1, '2018-07-16 07:14:31', '2018-07-16 12:44:31'),
(42, 4, 36, 'wjcID6ehKpwmtIQeJMAmNY8R4SBprgUi3q33ENG7ZCB1MOsRnKZYhNdPzGlG.jpg', 1, '2018-07-16 07:23:21', '2018-07-16 12:53:21'),
(43, 4, 37, 'pC9FionIimtbnNwVYE7uCI0XCpbebBCRtonu9MC0nzwZ8LmR6BRKj0OshFpE.jpg', 1, '2018-07-16 07:24:44', '2018-07-16 12:54:44'),
(44, 6, 38, 'G9ORixzUBZ9Zr0QNJ8xBCWc7wEppXj8t8Q1BW9QZVSpliycnKX6GEg73z9Em.jpg', 1, '2018-07-16 08:22:47', '2018-07-16 13:52:47'),
(45, 6, 39, 'q3ec8S4g3e7MyBlhUOUjyAt5RfMVQ3ufVBHMfp4YwM7Ow033XlwHQL9bzOgJ.jpg', 1, '2018-07-16 08:24:00', '2018-07-16 13:54:00'),
(46, 4, 40, 'PjuH4paKKQSEJC6TzEf2BnsQuaHz7Nf6DdKLezoZMJaZDzNv4bzTzpGQRmjz.jpg', 1, '2018-07-16 08:35:24', '2018-07-16 14:05:24'),
(47, 4, 41, '9ArgjkuKsouLagt6wblLFib7kz8guKMsFnIOtJqMCAejmS9uWreyPgXbzTEj.jpg', 1, '2018-07-16 08:38:39', '2018-07-16 14:08:39'),
(48, 3, 42, 'ydWlq2O5FIVH3I5ItQfUpRGQTJf3ND4pOzWoOsHIDZUh2CtXdxCzbYSgYMYD.jpg', 1, '2018-07-16 23:53:08', '2018-07-17 05:23:08'),
(49, 1, 18, 'EN79GSqxq8VO5T3PkjROO5g4O5IXapbW8lTDKE0Aikmk5O3yUurqU8ftjNxU.jpg', 1, '2018-07-17 01:27:02', '2018-07-17 06:57:02'),
(50, 7, 43, '7Q91X3VHK8vDJHHziZ7HnhT8js8pbYHKYp1ZCYTWE5zN4h05N5X65T7QLD4C.jpg', 1, '2018-07-27 03:45:46', '2018-07-27 09:15:46'),
(51, 1, 19, 'KVsGrCQbbZpE609tQGxtoD9EOTE7ZJ4RCfSwlqUc2ctGDidpdliII1Lsp8A8.jpg', 1, '2018-07-27 03:46:38', '2018-07-27 09:16:38'),
(52, 7, 44, 'wxXke631o0gJfBKeMUWh3TfD9O8q19wySYyBodwJjTHjbYowT89rJWkJzE9t.jpg', 1, '2018-07-27 04:06:20', '2018-07-27 09:36:20'),
(53, 7, 44, 'OaMXDJ565mem3RGOaA9t1FnkH5M0dNlylbI3DorAut4RgxCx6fclyzb4V122.jpg', 1, '2018-07-27 04:06:59', '2018-07-27 09:36:59');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_product_prices`
--

CREATE TABLE `tbl_product_prices` (
  `id` int(11) NOT NULL,
  `client_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `product_price` float NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tbl_product_prices`
--

INSERT INTO `tbl_product_prices` (`id`, `client_id`, `product_id`, `product_price`, `status`, `created_at`, `updated_at`) VALUES
(1, 1, 1, 111, 0, '2018-05-17 06:11:34', '2018-05-17 06:29:39'),
(2, 1, 1, 111, 1, '2018-05-17 06:29:39', '2018-05-17 06:29:39'),
(3, 1, 2, 123, 1, '2018-05-17 06:31:50', '2018-05-17 06:31:50'),
(4, 1, 5, 222, 0, '2018-05-17 06:34:28', '2018-07-13 06:57:39'),
(5, 1, 5, 555, 0, '2018-05-17 06:34:54', '2018-07-13 06:57:39'),
(6, 2, 6, 211, 1, '2018-07-11 11:36:15', '2018-07-11 11:36:15'),
(7, 1, 7, 5, 1, '2018-07-11 11:54:55', '2018-07-11 11:54:55'),
(8, 1, 8, 211, 1, '2018-07-11 12:21:41', '2018-07-11 12:21:41'),
(9, 1, 8, 211, 1, '2018-07-12 06:05:55', '2018-07-12 06:05:55'),
(10, 2, 9, 1313, 1, '2018-07-12 06:58:21', '2018-07-12 06:58:21'),
(11, 2, 10, 211, 1, '2018-07-12 07:11:09', '2018-07-12 07:11:09'),
(12, 1, 11, 2112, 1, '2018-07-12 13:38:29', '2018-07-12 13:38:29'),
(13, 1, 13, 2323, 0, '2018-07-12 13:43:19', '2018-07-13 05:35:25'),
(14, 1, 14, 1200, 1, '2018-07-12 13:52:13', '2018-07-12 13:52:13'),
(15, 1, 15, 1200, 1, '2018-07-12 13:53:00', '2018-07-12 13:53:00'),
(16, 1, 16, 2114, 0, '2018-07-12 13:58:59', '2018-07-14 10:10:51'),
(17, 1, 17, 350, 0, '2018-07-12 14:03:58', '2018-07-16 09:01:21'),
(18, 1, 18, 350, 0, '2018-07-12 14:06:19', '2018-07-17 06:57:02'),
(19, 1, 19, 10000, 0, '2018-07-12 14:12:12', '2018-07-27 09:16:38'),
(20, 1, 20, 300, 1, '2018-07-12 14:14:18', '2018-07-12 14:14:18'),
(21, 1, 21, 211, 1, '2018-07-13 04:54:10', '2018-07-13 04:54:10'),
(22, 1, 22, 211, 1, '2018-07-13 04:54:16', '2018-07-13 04:54:16'),
(23, 1, 23, 5000, 1, '2018-07-13 04:59:50', '2018-07-13 04:59:50'),
(24, 1, 24, 5435, 1, '2018-07-13 05:01:56', '2018-07-13 05:01:56'),
(25, 1, 13, 2323, 1, '2018-07-13 05:35:25', '2018-07-13 05:35:25'),
(26, 1, 5, 555, 1, '2018-07-13 06:57:39', '2018-07-13 06:57:39'),
(27, 1, 25, 100000, 1, '2018-07-13 09:07:26', '2018-07-13 09:07:26'),
(28, 1, 16, 2114, 0, '2018-07-14 06:52:04', '2018-07-14 10:10:51'),
(29, 1, 16, 21146, 0, '2018-07-14 07:48:48', '2018-07-14 10:10:51'),
(30, 1, 18, 350, 0, '2018-07-14 07:49:50', '2018-07-17 06:57:02'),
(31, 1, 18, 350, 0, '2018-07-14 08:05:14', '2018-07-17 06:57:02'),
(32, 1, 16, 21146, 1, '2018-07-14 10:10:51', '2018-07-14 10:10:51'),
(33, 1, 26, 23455, 1, '2018-07-16 08:24:28', '2018-07-16 08:24:28'),
(34, 1, 27, 7979, 1, '2018-07-16 08:25:21', '2018-07-16 08:25:21'),
(35, 1, 28, 3548360, 1, '2018-07-16 08:47:22', '2018-07-16 08:47:22'),
(36, 3, 29, 345, 1, '2018-07-16 08:57:32', '2018-07-16 08:57:32'),
(37, 1, 17, 350, 1, '2018-07-16 09:01:21', '2018-07-16 09:01:21'),
(38, 3, 30, 323546, 1, '2018-07-16 09:03:34', '2018-07-16 09:03:34'),
(39, 3, 31, 234567, 1, '2018-07-16 10:05:21', '2018-07-16 10:05:21'),
(40, 4, 32, 12345, 1, '2018-07-16 10:56:30', '2018-07-16 10:56:30'),
(41, 4, 33, 123456, 1, '2018-07-16 11:01:09', '2018-07-16 11:01:09'),
(42, 6, 34, 23234, 1, '2018-07-16 12:42:24', '2018-07-16 12:42:24'),
(43, 6, 35, 23234, 1, '2018-07-16 12:44:31', '2018-07-16 12:44:31'),
(44, 4, 36, 45354, 1, '2018-07-16 12:53:21', '2018-07-16 12:53:21'),
(45, 4, 37, 7576430, 1, '2018-07-16 12:54:44', '2018-07-16 12:54:44'),
(46, 6, 38, 3000, 1, '2018-07-16 13:52:47', '2018-07-16 13:52:47'),
(47, 6, 39, 34000, 1, '2018-07-16 13:54:00', '2018-07-16 13:54:00'),
(48, 4, 40, 150, 1, '2018-07-16 14:05:24', '2018-07-16 14:05:24'),
(49, 4, 41, 111, 1, '2018-07-16 14:08:39', '2018-07-16 14:08:39'),
(50, 3, 42, 123456, 1, '2018-07-17 05:23:08', '2018-07-17 05:23:08'),
(51, 1, 18, 350, 1, '2018-07-17 06:57:02', '2018-07-17 06:57:02'),
(52, 7, 43, 3423, 1, '2018-07-27 09:15:46', '2018-07-27 09:15:46'),
(53, 1, 19, 10000, 1, '2018-07-27 09:16:38', '2018-07-27 09:16:38'),
(54, 7, 44, 12000, 0, '2018-07-27 09:36:20', '2018-07-27 09:36:59'),
(55, 7, 44, 12000, 1, '2018-07-27 09:36:59', '2018-07-27 09:36:59');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_product_specifications`
--

CREATE TABLE `tbl_product_specifications` (
  `id` int(11) NOT NULL,
  `client_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `product_key` varchar(191) NOT NULL,
  `product_value` varchar(191) NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tbl_product_specifications`
--

INSERT INTO `tbl_product_specifications` (`id`, `client_id`, `product_id`, `product_key`, `product_value`, `status`, `created_at`, `updated_at`) VALUES
(17, 1, 3, 'ssssss', 'ssssssssss', 1, '2018-05-16 09:23:57', '2018-05-16 14:53:57'),
(22, 1, 4, 'k1', 'k1', 1, '2018-05-16 10:13:16', '2018-05-16 15:43:16'),
(23, 1, 4, 'k2', 'k2', 1, '2018-05-16 10:13:17', '2018-05-16 15:43:17'),
(27, 1, 1, 'k3', 'k3', 1, '2018-05-17 00:59:39', '2018-05-17 06:29:39'),
(28, 1, 1, 'k1', 'k1', 1, '2018-05-17 00:59:39', '2018-05-17 06:29:39'),
(29, 1, 1, 'k2', 'k2', 1, '2018-05-17 00:59:39', '2018-05-17 06:29:39'),
(33, 1, 14, 'A', '123', 1, '2018-07-12 08:22:13', '2018-07-12 13:52:13'),
(36, 1, 13, 'yu', 'Ai', 1, '2018-07-13 00:05:26', '2018-07-13 05:35:26'),
(37, 1, 5, 'ggcxc', 'gg', 1, '2018-07-13 01:27:39', '2018-07-13 06:57:39'),
(40, 1, 16, '4', '4', 1, '2018-07-14 04:40:51', '2018-07-14 10:10:51'),
(41, 1, 26, '4543', '21323', 1, '2018-07-16 02:54:28', '2018-07-16 08:24:28'),
(42, 1, 28, '23', '45', 1, '2018-07-16 03:17:23', '2018-07-16 08:47:23'),
(43, 1, 17, 'c', 'c', 1, '2018-07-16 03:31:21', '2018-07-16 09:01:21'),
(44, 4, 33, '3768', '45676', 1, '2018-07-16 05:31:09', '2018-07-16 11:01:09'),
(45, 4, 37, 'rtr', 'rter', 1, '2018-07-16 07:24:44', '2018-07-16 12:54:44'),
(46, 6, 38, '23', '56', 1, '2018-07-16 08:22:47', '2018-07-16 13:52:47'),
(47, 4, 41, '2', '23', 1, '2018-07-16 08:38:39', '2018-07-16 14:08:39'),
(48, 3, 42, '23456', '4321', 1, '2018-07-16 23:53:08', '2018-07-17 05:23:08'),
(49, 7, 43, 'ffg', 'dsfsdfsdf', 1, '2018-07-27 03:45:46', '2018-07-27 09:15:46'),
(50, 7, 43, 'xcvxcvvxc', 'sdsdsdf', 1, '2018-07-27 03:45:46', '2018-07-27 09:15:46'),
(51, 1, 19, 'dsfdsfdsf', 'dsfsdfsdf', 1, '2018-07-27 03:46:38', '2018-07-27 09:16:38'),
(53, 7, 44, 'dsfdsfdsf', 'dsfdsfdsf', 1, '2018-07-27 04:06:59', '2018-07-27 09:36:59');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_status_masters`
--

CREATE TABLE `tbl_status_masters` (
  `id` int(11) NOT NULL,
  `name` varchar(20) NOT NULL,
  `description` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tbl_status_masters`
--

INSERT INTO `tbl_status_masters` (`id`, `name`, `description`) VALUES
(0, 'Inactive', 'Inactive'),
(1, 'Active', 'Active');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_themes`
--

CREATE TABLE `tbl_themes` (
  `id` int(11) NOT NULL,
  `color_code` varchar(250) NOT NULL,
  `client_id` int(11) NOT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tbl_themes`
--

INSERT INTO `tbl_themes` (`id`, `color_code`, `client_id`, `created_at`, `updated_at`) VALUES
(1, '#FF0000', 1, '2018-05-17 07:04:28', '2018-05-17 07:04:28'),
(2, '#02141d', 3, '2018-07-19 07:18:22', '2018-07-19 07:18:22');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_users`
--

CREATE TABLE `tbl_users` (
  `id` int(10) UNSIGNED NOT NULL,
  `user_type` tinyint(4) NOT NULL,
  `client_id` int(11) NOT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `api_token` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `tbl_users`
--

INSERT INTO `tbl_users` (`id`, `user_type`, `client_id`, `email`, `password`, `api_token`, `remember_token`, `created_at`, `updated_at`) VALUES
(1, 1, 1, 'cyber@gmail.com', '$2y$10$NtdL3WVy58IUZLm/JoyxzunBJWQqc8rdxOjDW/Rjur3ElBHZZMDhm', 'f06CII7WcQX9IDKqxtYFmzPRyI7WMNErsyBagzQkTp4OZDXzf0tazX9ILsJ2', 'T99sQuso4ZxOaRk02NdKnWyYMGNsSPLQjS2YCNgbYaHCXRT2OuWx9QJ00FOM', '2018-05-11 08:14:56', '2018-05-11 08:14:56'),
(2, 1, 2, 'herohonda@gmail.com', '$2y$10$9n9zdCY.wzXyq.DZXnHl1OjUrrERLCEwQn1yAy1HC/FiVT46mPV5K', 'xGRbsnl5C5pAa5RBc5wcpX9RmRkUEWc0aegAWIkLu5KoEtKLeMaJQvOMAMS7', 'uNambL1NCXjFTayGOYm9fKcpZUlVrB9QpG6pTSW12VOhB0Wv5LueJtIyetlg', '2018-05-14 02:50:21', '2018-05-14 02:50:21'),
(3, 1, 3, 'pankaj@gmail.com', '$2y$10$XfDKIOSEvmTYVGUO4LQjWe1VPGjbYyo1RIdDXBrt/hLg8MuUTH8Ei', 'IqU0XjHkKqvCMGbgS2He7d5cx9SjyzZGI8wYSkSDAvqdgYGaNS8wDHebthy6', 'F4tQ6Wo30QQ4DuEKrfFrJ8m3lEn3s3NurdYLJsE0F4vAAY6BiUgXxVbxrFQW', '2018-07-11 01:40:36', '2018-07-11 01:40:36'),
(4, 1, 4, 'pankajj@gmail.com', '$2y$10$fRFfB.9xUUcD2DoAMTNQe.Os03DvSht8cxxRtiWFp0GJbEQRkZWMe', 'ZxbKwhUBTH97PKnL6wlrvkEPNWKA02uCFHsCjbFwHH92ylRgrSObzTwFSOuR', NULL, '2018-07-11 01:45:50', '2018-07-11 01:45:50'),
(5, 1, 3, 'pankaj4@gmail.com', '$2y$10$qI2A/7OyH5Z67ONYWfGCauXqoUgzi2k1D6wLiZAEqsboGtm3i9Hi.', 'qqmty4i8JJq4okdkyKQSijB7eUmIVWeliZcv7sORiyH29bbowxJOevJ1gJB1', NULL, '2018-07-16 01:33:47', '2018-07-16 01:33:47'),
(6, 1, 4, 'shubham@mail.com', '$2y$10$snCSlOlaKa5WddvREIjsOOqxW4lcZ09EDzcgwQ/yIfyUJM4J.JVdW', 'qVATCwnwoJvKiUsqDgNaPZWxceqj4UMZPMBTGHQi9N8VrobNX9H5y1xqruLf', 'HZASjCla4VT3r18ZbBz8zRYOVywltLC5kro8EjilkqkvSYqxMVtOkc0YpRZD', '2018-07-16 04:40:42', '2018-07-16 04:40:42'),
(7, 1, 5, 'shubham@mail.com', '$2y$10$FZgeObikjUqtKMPDR87bSOY/v8U7PKvBqv30rYUF7I3zWTYk7cy2y', 'zP8Aj3oxwmaLf4H020enn3iCaN2h34M9t9VxWksuZW9bG3dtJZ4iYFMK76Pz', NULL, '2018-07-16 04:40:42', '2018-07-16 04:40:42'),
(8, 1, 6, 'hcl@gmail.com', '$2y$10$dI5nVUBnmYqzN88rO9RNIesBfCLrU243nE1dFOmo0oXz/Zk5mFvZm', 'mOXyp2F5woCcG252eaGYvDKv48OI0CjPLwJXfbIwmQUi0ciSW5k95sJucpYM', 'PKtjk2WyIuLfqsf0vPKWkREkzSqnDHuhDm9SmVzqrOsfuYahiIRXcrJvcsjH', '2018-07-16 08:18:33', '2018-07-16 08:18:33'),
(9, 1, 7, 'tech@gmail.com', '$2y$10$7CpAjpPynlFjGQw6lcchu.nMjJwWnCugd9cIN.ncYJrH9agJ9cpeq', '4ZAHomDckpe2VVztrVzttzZOOKiE2T7AxuqndoroQJViQM7aSofv5JSqy0WG', NULL, '2018-07-27 03:25:38', '2018-07-27 03:25:38'),
(10, 1, 8, 'vijay@gmail.com', '$2y$10$7iv6EV72pWcL7umBAIjXDOfWGbKw5o07wRPxjx3VDp/jN24t/3JJ6', 'yak7NDgu8sMHEdLFPoeiJ9FlsE5SF2mhMEonDxnnAMws3g7gsQShL4rohxZE', NULL, '2018-07-27 04:08:19', '2018-07-27 04:08:19');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_user_status_masters`
--

CREATE TABLE `tbl_user_status_masters` (
  `id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `description` varchar(191) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tbl_user_status_masters`
--

INSERT INTO `tbl_user_status_masters` (`id`, `name`, `description`) VALUES
(0, 'Inactive', 'Active'),
(1, 'Active', 'Inactive'),
(3, 'Deactivated by user', 'Deactivated by user'),
(4, 'Deactivated by admin', 'Deactivated by admin');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tbl_admins`
--
ALTER TABLE `tbl_admins`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`),
  ADD UNIQUE KEY `api_token` (`api_token`);

--
-- Indexes for table `tbl_categories`
--
ALTER TABLE `tbl_categories`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_category_banners`
--
ALTER TABLE `tbl_category_banners`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_clients`
--
ALTER TABLE `tbl_clients`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_customers`
--
ALTER TABLE `tbl_customers`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_enquiries`
--
ALTER TABLE `tbl_enquiries`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_migrations`
--
ALTER TABLE `tbl_migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_password_resets`
--
ALTER TABLE `tbl_password_resets`
  ADD KEY `password_resets_email_index` (`email`);

--
-- Indexes for table `tbl_products`
--
ALTER TABLE `tbl_products`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_product_banners`
--
ALTER TABLE `tbl_product_banners`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_product_images`
--
ALTER TABLE `tbl_product_images`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_product_prices`
--
ALTER TABLE `tbl_product_prices`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_product_specifications`
--
ALTER TABLE `tbl_product_specifications`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_status_masters`
--
ALTER TABLE `tbl_status_masters`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_themes`
--
ALTER TABLE `tbl_themes`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_users`
--
ALTER TABLE `tbl_users`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_user_status_masters`
--
ALTER TABLE `tbl_user_status_masters`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `name` (`name`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tbl_admins`
--
ALTER TABLE `tbl_admins`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `tbl_categories`
--
ALTER TABLE `tbl_categories`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=118;

--
-- AUTO_INCREMENT for table `tbl_category_banners`
--
ALTER TABLE `tbl_category_banners`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=56;

--
-- AUTO_INCREMENT for table `tbl_clients`
--
ALTER TABLE `tbl_clients`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `tbl_customers`
--
ALTER TABLE `tbl_customers`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tbl_enquiries`
--
ALTER TABLE `tbl_enquiries`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tbl_migrations`
--
ALTER TABLE `tbl_migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `tbl_products`
--
ALTER TABLE `tbl_products`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=45;

--
-- AUTO_INCREMENT for table `tbl_product_banners`
--
ALTER TABLE `tbl_product_banners`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=44;

--
-- AUTO_INCREMENT for table `tbl_product_images`
--
ALTER TABLE `tbl_product_images`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=54;

--
-- AUTO_INCREMENT for table `tbl_product_prices`
--
ALTER TABLE `tbl_product_prices`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=56;

--
-- AUTO_INCREMENT for table `tbl_product_specifications`
--
ALTER TABLE `tbl_product_specifications`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=54;

--
-- AUTO_INCREMENT for table `tbl_themes`
--
ALTER TABLE `tbl_themes`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `tbl_users`
--
ALTER TABLE `tbl_users`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
